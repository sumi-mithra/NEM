const mongoose= require('mongoose');

var employeeSchema = new mongoose.Schema({

    Name: {
        type:String,
        required:"this field is required"
    },
    email: {
        type:String
    },
    mobile: {
        type:String
    }
});

mongoose.model('Employee',employeeSchema);