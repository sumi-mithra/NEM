const express= require('express');
var router = express.Router();
const mongoose= require('mongoose');
const Employee= mongoose.model('Employee');


router.get('/',(req,res)=>{
    res.render('employee/add',{viewtitle:"Insert employee details"});

});

router.post('/',(req,res)=>{
    insertRecord(req,res);
});

function insertRecord(req,res)
{
    var employee=new Employee();
    employee.Name=req.body.Name;
    employee.email=req.body.email;
    employee.mobile=req.body.mobile;
    employee.save((err,doc)=>{
        if(!err)
            res.redirect('employee/list');
        else{
            console.log('error'+err);
        }
    });
}

router.get('/list',(req,res)=>{

    Employee.find((err,docs)=>{
        if(!err){
            res.render("employee/list",{
                list:docs
            });
        }
        else{
        console.log('error'+err);
        }
    });

});
module.exports=router;